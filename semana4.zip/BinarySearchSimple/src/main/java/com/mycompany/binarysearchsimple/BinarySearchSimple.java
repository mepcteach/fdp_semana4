/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.binarysearchsimple;

/**
 *
 * @author mpuebla
 */
public class BinarySearchSimple {

    public static void main(String[] args) {
        int[] numbers = {10, 20, 30, 40, 50}; // Array ordenado
        int target = 30; // Valor a buscar
        
        // Búsqueda binaria en el array
        int low = 0;
        int high = numbers.length - 1;
        int index = -1;
        
        while (low <= high) {
            int mid = (low + high) / 2;
            
            if (numbers[mid] == target) {
                index = mid;
                break;
            } else if (numbers[mid] < target) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }
        
        // Mostrar el resultado
        if (index != -1) {
            System.out.println("Valor " + target + " encontrado en el índice " + index);
        } else {
            System.out.println("Valor " + target + " no encontrado en el array.");
        }
    }
}
