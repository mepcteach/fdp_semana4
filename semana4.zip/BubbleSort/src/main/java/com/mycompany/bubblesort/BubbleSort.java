/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bubblesort;

/**
 *
 * @author mpuebla
 */
public class BubbleSort { 
    public static void main(String[] args) {
        // Array de ejemplo
        int[] arr = {64, 34, 25, 12, 22, 11, 90, 25};
        int n = arr.length;
        
        // Ordenamiento por burbuja
        for (int i = 0; i < n - 1; i++) {
            boolean swapped = false;
            for (int j = 0; j < n - i - 1; j++) {
                // Comparar el elemento actual con el siguiente
                if (arr[j] > arr[j + 1]) {
                    // Intercambiar los elementos si están en el orden incorrecto
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                    swapped = true;
                }
            }
            // Si no hubo intercambios, el array ya está ordenado
            if (!swapped) break;
        }
        
        // Imprimir el array ordenado
        System.out.println("Array ordenado:");
        for (int i = 0; i < n; i++) {
            System.out.print(arr[i] + " ");
        }
    }
}
