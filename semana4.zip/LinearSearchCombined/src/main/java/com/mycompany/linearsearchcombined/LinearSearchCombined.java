/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.linearsearchcombined;

/**
 *
 * @author mpuebla
 */
public class LinearSearchCombined {

    public static void main(String[] args) {
        int[] numbers = {10, 20, 30, 40, 50}; // Array de ejemplo
        int target = 40; // Valor a buscar

        // Búsqueda lineal usando bucle for
        int indexUsingFor = -1; // Inicializar índice como no encontrado
        for (int i = 0; i < numbers.length; i++) {
            if (numbers[i] == target) {
                indexUsingFor = i; // Valor encontrado, guardar el índice
                break; // Salir del bucle ya que se encontró el valor
            }
        }

        // Mostrar resultado de la búsqueda con bucle for
        if (indexUsingFor != -1) {
            System.out.println("Búsqueda con for: Valor " + target + " encontrado en el índice " + indexUsingFor);
        } else {
            System.out.println("Búsqueda con for: Valor " + target + " no encontrado en el array.");
        }

        // Búsqueda lineal usando bucle while
        int indexUsingWhile = -1; // Inicializar índice como no encontrado
        int i = 0; // Índice inicial para el bucle while
        while (i < numbers.length) {
            if (numbers[i] == target) {
                indexUsingWhile = i; // Valor encontrado, guardar el índice
                break; // Salir del bucle ya que se encontró el valor
            }
            i++; // Incrementar el índice para continuar con el siguiente elemento
        }

        // Mostrar resultado de la búsqueda con bucle while
        if (indexUsingWhile != -1) {
            System.out.println("Búsqueda con while: Valor " + target + " encontrado en el índice " + indexUsingWhile);
        } else {
            System.out.println("Búsqueda con while: Valor " + target + " no encontrado en el array.");
        }
    }
}
