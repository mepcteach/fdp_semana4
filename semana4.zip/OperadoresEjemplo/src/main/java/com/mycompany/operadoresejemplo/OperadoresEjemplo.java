/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.operadoresejemplo;

/**
 *
 * @author mpuebla
 */
public class OperadoresEjemplo {
    public static void main(String[] args) {
        // Operadores Aritméticos
        int a = 10, b = 5, c = 3;
        // Operación aritmética combinada
        int resultadoAritmetico = (a + b) * c / (b - a % c);
        System.out.println("Resultado de la operación aritmética combinada: " + resultadoAritmetico); // (15 * 3) / 4 (-1) = -45: Resultado: 11
        
        // Operadores Relacionales
        System.out.println("a es igual a b: " + (+a == b)); // false
        System.out.println("a es mayor que b: " + (a > b)); // true
        
        // Operadores Lógicos
        boolean esAdulto = true;
        boolean tieneLicencia = false;
        boolean tieneExperiencia = true;
        // Operación lógica combinada
        boolean resultadoLogico = (esAdulto && tieneLicencia) || tieneExperiencia;
        System.out.println("Es adulto y tiene licencia o tiene experiencia: " + resultadoLogico); // true
        
        // Operadores de Asignación
        int x = 5;
        x += 3; // x = x + 3
        System.out.println("x después de += 3: " + x); // 8
        
        // Operadores Unarios
        int y = -10;
        System.out.println("Valor de y: " + y); // -10
        System.out.println("Negación de y: " + (-y)); // 10
        System.out.println("Incremento de x: " + (++x)); // 9
        System.out.println("Decremento de x: " + (x--)); // 9 luego x = 8
        
        // Operadores Ternarios
        String resultado = (x > 10) ? "Mayor que 10" : "10 o menor";
        System.out.println("Resultado del operador ternario: " + resultado); // "10 o menor"
        
        // Operadores de Comparación de Referencia
        String str1 = new String("Hola");
        String str2 = new String("Hola");
        System.out.println("str1 y str2 son iguales: " + (str1 == str2)); // false
        System.out.println("str1 y str2 tienen el mismo valor: " + str1.equals(str2)); // true
    }
}
