package com.mycompany.rectangleareacalculator;

/**
 *
 * @author mpuebla
 */
/**
 * Calcula el área de un rectángulo.
 */
public class RectangleAreaCalculator {
    public static void main(String[] args) {
        // Ejemplo de uso de la clase RectangleAreaCalculator
        try {
            // Crear una instancia de RectangleAreaCalculator con ancho y altura válidos
            AreaCalculator rectangle = new AreaCalculator(10, 5);
            
            // Calcular y mostrar el área del rectángulo
            double area = rectangle.calculateArea();
            System.out.println("Área del rectángulo: " + area);

            // Modificar las dimensiones del rectángulo
            rectangle.setWidth(8);
            rectangle.setHeight(12);

            // Calcular y mostrar el nuevo área del rectángulo
            double newArea = rectangle.calculateArea();
            System.out.println("Nueva área del rectángulo: " + newArea);
            
        } catch (IllegalArgumentException e) {
            // Manejar la excepción si se proporciona una dimensión inválida
            System.out.println("Error: " + e.getMessage());
        }
    }
}

/**
 * Calcula el área de un rectángulo.
 */
class AreaCalculator {

    private double width; // Ancho del rectángulo
    private double height; // Altura del rectángulo

    /**
     * Constructor de la clase AreaCalculator.
     * 
     * @param width El ancho del rectángulo.
     * @param height La altura del rectángulo.
     */
    public AreaCalculator(double width, double height) {
        setWidth(width); // Usa el método para validar el ancho
        setHeight(height); // Usa el método para validar la altura
    }

    /**
     * Calcula el área del rectángulo.
     * 
     * @return El área del rectángulo.
     */
    public double calculateArea() {
        return width * height;
    }

    /**
     * Establece el ancho del rectángulo.
     * 
     * @param width El nuevo ancho del rectángulo.
     */
    public void setWidth(double width) {
        if (width <= 0) {
            throw new IllegalArgumentException("El ancho debe ser mayor que cero.");
        }
        this.width = width;
    }

    /**
     * Establece la altura del rectángulo.
     * 
     * @param height La nueva altura del rectángulo.
     */
    public void setHeight(double height) {
        if (height <= 0) {
            throw new IllegalArgumentException("La altura debe ser mayor que cero.");
        }
        this.height = height;
    }
}
