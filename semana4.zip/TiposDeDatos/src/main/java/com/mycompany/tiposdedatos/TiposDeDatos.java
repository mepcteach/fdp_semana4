/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tiposdedatos;

/**
 *
 * @author mpuebla
 */
import java.util.Arrays; // Importación necesaria para manipular arrays


public class TiposDeDatos {

    public static void main(String[] args) {
        
        
        // 1. Tipos de Datos Primitivos
        int edad = 25; // Tipo de dato primitivo: int
        double salario = 45890.75; // Tipo de dato primitivo: double
        char inicial = 'A'; // Tipo de dato primitivo: char
        boolean esEmpleado  = true; // Tipo de dato primitivo: boolean
        
        // Uso de métodos para clases envoltorio (Wrapper Classes)
        Integer edadEnvoltorio = Integer.valueOf(edad); // No primitivo (envoltorio para int)
        Double salarioEnvoltorio = Double.valueOf(salario); // No primitivo (envoltorio para double)
        
        // Métodos de clases envoltorio
        System.out.println("Edad en formato de binario: " + Integer.toBinaryString(edadEnvoltorio)); // Método para convertir int a binario
        System.out.println("Salario redondeado: " + Math.round(salarioEnvoltorio)); // Método Math para redondear un double
        
        // 2. Tipos de Datos No Primitivos
        String nombre = "Juan Perez"; // Tipo de dato no primitivo: String
        int[] numeros = {80,10, 20, 30, 40, 50}; // Tipo de dato no primitivo: Array
        Persona persona = new Persona("Juan", "Perez", 30); // Tipo de dato no primitivo: Clase (Objeto)
        Persona personaExtranjera = new Persona("John", "Smith", 49); // Tipo de dato no primitivo: Clase (Objeto)
        
        // Uso de métodos con String
        System.out.println("Nombre en mayúsculas: " + nombre.toUpperCase()); // Convierte el nombre a mayúsculas
        System.out.println("Longitud del nombre: " + nombre.length()); // Devuelve la longitud del nombre
        
        // Uso de métodos con Array
        System.out.println("Elementos del array: " + Arrays.toString(numeros)); // Imprime los elementos del array
        Arrays.sort(numeros); // Ordena el array
        System.out.println("Elementos del array ordenados: " + Arrays.toString(numeros)); // Imprime los elementos ordenados del array
        
        // Mostrar información del objeto Persona
        persona.mostrarInfo();
        personaExtranjera.mostrarInfo();
        
        // Uso de un enum
        Dia diaDeLaSemana = Dia.MARTES; // Tipo de dato no primitivo: Enum
        System.out.println("Día de la semana seleccionado: " + diaDeLaSemana); // Imprime el valor del enum
    }
}

// Definición de una clase (no primitivo)
class Persona {
    String nombre; // No primitivo: String
    String apellido; // No primitivo: String
    int edad; // Primitivo: int

    // Constructor de la clase
    public Persona(String nombre, String apellido, int edad) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
    }

    // Método para mostrar información de la persona
    public void mostrarInfo() {
        System.out.println("Nombre completo: " + nombre + " " + apellido);
        System.out.println("Edad: " + edad);
    }
}

// Definición de un enum (no primitivo)
enum Dia {
    LUNES, MARTES, MIERCOLES, JUEVES, VIERNES, SABADO, DOMINGO
}
