/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.estructurascontrol;

import java.util.Scanner; 

/**
 *
 * @author mpuebla
 */
public class EstructurasControl { 
 
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int dia = 0;

        System.out.println("USAM+OS DO WHILE / IF ELSE ");
        System.out.println("=================================");
       
        // 1. Solicitar un número entre 1 y 7 al usuario
        do {
            System.out.print("Ingresa un número del 1 al 7 para representar un día de la semana:  ");
            if (scanner.hasNextInt()) {
                dia = scanner.nextInt();

                // Validación de entrada
                if (dia < 1 || dia > 7) {
                    System.out.println("Número inválido. Por favor, ingresa un número entre 1 y 7.");
                }
            } else {
                System.out.println("Entrada no válida. Por favor, ingresa un número entero.");
                scanner.next(); // Limpiar entrada incorrecta
            }
        } while (dia < 1 || dia > 7);
        
        System.out.println();
        System.out.println("USO DEL SWITCH ");
        System.out.println("=================================");
       

        // 2. Usar switch para mostrar el día de la semana
        switch (dia) {
            case 1:
                System.out.println("Lunes");
                break;
            case 2:
                System.out.println("Martes");
                break;
            case 3:
                System.out.println("Miércoles");
                break;
            case 4:
                System.out.println("Jueves");
                break;
            case 5:
                System.out.println("Viernes");
                break;
            case 6:
                System.out.println("Sábado");
                break;
            case 7:
                System.out.println("Domingo");
                break;
        }

        
        System.out.println();
        System.out.println("USAMOS FOR ");
        System.out.println("================================="); 
        
        // 3. Usar for para imprimir los números del 1 al 10
        System.out.println("Números del 1 al 10:");
        for (int i = 1; i <= 10; i++) {
            System.out.print(i + " ");
        }
        System.out.println();
        
       
        System.out.println();
        System.out.println("USAMOS  WHILE  ");
        System.out.println("================================="); 

        // 4. Usar while para contar desde 1 hasta el número ingresado
        System.out.println("Contar desde 1 hasta " + dia + ":");
        int contador = 1;
        while (contador <= dia) {
            System.out.print(contador + " ");
            contador++;
        }
        System.out.println();

        
        System.out.println();
        System.out.println("USAMOS  DO WHILE  ");
        System.out.println("================================="); 
        
        // 5. Usar do-while para contar hacia atrás desde el número ingresado hasta 1
        System.out.println("Contar hacia atrás desde " + dia + " hasta 1:");
        int contadorAtras = dia;
        do {
            System.out.print(contadorAtras + " ");
            contadorAtras--;
        } while (contadorAtras >= 1);
        System.out.println();
        
        
        System.out.println();
        System.out.println("USAMOS  IF ELSE  ");
        System.out.println("=================================");

        // 6. Usar if-else para verificar si el número ingresado es par o impar
        if (dia % 2 == 0) {
            System.out.println("El número " + dia + " es par.");
        } else {
            System.out.println("El número " + dia + " es impar.");
        }

        scanner.close();
    }
}
 
